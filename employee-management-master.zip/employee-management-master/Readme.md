**How to run project**   
1. git clone https://github.com/piyaarora/employee-management/
2. npm install
3. cd client -> npm install
4. add default.json in config folder containing code 

`````````
{
    "mongoURI": "",
    "jwtSecret": ""
}

`````````

5. run command ***npm run dev***