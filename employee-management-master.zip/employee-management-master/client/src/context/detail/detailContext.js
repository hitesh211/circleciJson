import { createContext } from 'react'

const detailContext = createContext();

export default detailContext;
